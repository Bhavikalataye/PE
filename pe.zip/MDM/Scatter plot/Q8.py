import matplotlib.pyplot as plt

experience = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
salary = [20000, 25000, 30000, 35000, 40000, 45000, 50000, 60000, 65000, 70000]

plt.scatter(experience, salary)
plt.xlabel('Experience (years)')
plt.ylabel('Salary (₹)')
plt.title('Work Experience vs Salary')
plt.show()
