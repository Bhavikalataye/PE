import matplotlib.pyplot as plt

income = [20000, 30000, 40000, 50000, 60000, 70000]
spending = [15000, 20000, 25000, 30000, 35000, 40000]

plt.scatter(income, spending)
plt.xlabel('Income (₹)')
plt.ylabel('Spending (₹)')
plt.title('Income vs Spending')
plt.show()
