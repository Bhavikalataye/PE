import matplotlib.pyplot as plt

social_media_time = [1, 2, 3, 4, 5, 6, 7]
productivity = [90, 85, 75, 70, 60, 55, 50]

plt.scatter(social_media_time, productivity)
plt.xlabel('Social Media Time (hours/day)')
plt.ylabel('Productivity (%)')
plt.title('Social Media Time vs Productivity')
plt.show()
