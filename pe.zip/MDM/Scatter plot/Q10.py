import matplotlib.pyplot as plt

area = [800, 1000, 1200, 1500, 1800, 2000, 2500]
price = [30, 40, 50, 60, 75, 85, 100]

plt.scatter(area, price)
plt.xlabel('House Area (sq.ft)')
plt.ylabel('Market Price (lakhs ₹)')
plt.title('House Area vs Market Price')
plt.show()
