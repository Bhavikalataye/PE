import matplotlib.pyplot as plt

age = [25, 30, 35, 40, 45, 50, 55, 60]
cholesterol = [160, 170, 180, 200, 210, 230, 240, 250]

plt.scatter(age, cholesterol)
plt.xlabel('Age (years)')
plt.ylabel('Cholesterol Level (mg/dL)')
plt.title('Age vs Cholesterol Level')
plt.show()
