import matplotlib.pyplot as plt

temperature = [20, 22, 25, 27, 30, 33, 35]
sales = [100, 120, 150, 170, 200, 230, 250]

plt.scatter(temperature, sales)
plt.xlabel('Temperature (°C)')
plt.ylabel('Ice Cream Sales')
plt.title('Temperature vs Ice Cream Sales')
plt.show()
