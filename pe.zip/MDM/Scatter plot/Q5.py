import matplotlib.pyplot as plt

engine_size = [1.0, 1.2, 1.5, 1.8, 2.0, 2.5]
fuel_efficiency = [22, 20, 18, 15, 13, 10]

plt.scatter(engine_size, fuel_efficiency)
plt.xlabel('Engine Size (litres)')
plt.ylabel('Fuel Efficiency (km/l)')
plt.title('Engine Size vs Fuel Efficiency')
plt.show()
