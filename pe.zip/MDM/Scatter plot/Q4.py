import matplotlib.pyplot as plt

study_time = [1, 2, 3, 4, 5, 6, 7]
marks = [50, 55, 65, 70, 80, 85, 90]

plt.scatter(study_time, marks)
plt.xlabel('Study Time (hours)')
plt.ylabel('Marks Scored')
plt.title('Study Time vs Marks')
plt.show()
