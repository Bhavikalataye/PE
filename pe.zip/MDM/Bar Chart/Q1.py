import matplotlib.pyplot as plt

products = ['A', 'B', 'C', 'D']
sales = [150, 200, 120, 180]

plt.bar(products, sales)
plt.xlabel('Products')
plt.ylabel('Total Sales')
plt.title('Total Sales for Different Products')
plt.show()
