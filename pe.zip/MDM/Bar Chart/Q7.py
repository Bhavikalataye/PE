import matplotlib.pyplot as plt

countries = ['India', 'USA', 'China', 'Brazil']
population = [1400, 330, 1440, 213]

plt.bar(countries, population)
plt.xlabel('Countries')
plt.ylabel('Population (in millions)')
plt.title('Population of Different Countries')
plt.show()
