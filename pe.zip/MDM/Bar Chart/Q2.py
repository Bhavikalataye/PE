import matplotlib.pyplot as plt

subjects = ['Math', 'Science', 'English', 'History']
marks = [85, 78, 90, 88]

plt.bar(subjects, marks)
plt.xlabel('Subjects')
plt.ylabel('Average Marks')
plt.title('Average Marks for Subjects')

plt.show()
