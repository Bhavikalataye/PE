import matplotlib.pyplot as plt

quarters = ['Q1', 'Q2', 'Q3', 'Q4']
revenue = [50000, 60000, 70000, 80000]

plt.bar(quarters, revenue)
plt.xlabel('Quarters')
plt.ylabel('Revenue (₹)')
plt.title('Company Revenue Over Four Quarters')
plt.show()
