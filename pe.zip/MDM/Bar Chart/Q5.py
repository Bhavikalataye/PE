import matplotlib.pyplot as plt

departments = ['HR', 'IT', 'Sales', 'Finance']
employees = [10, 25, 15, 12]

plt.bar(departments, employees)
plt.xlabel('Departments')
plt.ylabel('Number of Employees')
plt.title('Employees in Each Department')
plt.show()
