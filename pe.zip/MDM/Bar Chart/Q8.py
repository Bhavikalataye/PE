import matplotlib.pyplot as plt

categories = ['Electronics', 'Clothing', 'Groceries', 'Toys']
orders = [300, 250, 400, 150]

plt.bar(categories, orders)
plt.xlabel('Product Categories')
plt.ylabel('Number of Orders')
plt.title('Online Orders by Product Category')
plt.show()
