import matplotlib.pyplot as plt

movies = ['Movie A', 'Movie B', 'Movie C', 'Movie D']
ratings = [4.5, 3.8, 4.2, 4.0]

plt.bar(movies, ratings)
plt.xlabel('Movies')
plt.ylabel('Ratings')
plt.title('Movie Ratings Comparison')
plt.show()
