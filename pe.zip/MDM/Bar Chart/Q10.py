import matplotlib.pyplot as plt

gender = ['Male', 'Female']
count = [40, 35]

plt.bar(gender, count, color=['blue', 'pink'])
plt.xlabel('Gender')
plt.ylabel('Number of Employees')
plt.title('Male vs Female Employees in the Company')
plt.show()
