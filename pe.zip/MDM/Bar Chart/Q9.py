import matplotlib.pyplot as plt

appliances = ['TV', 'Fridge', 'AC', 'Washing Machine']
usage = [50, 120, 300, 100]

plt.bar(appliances, usage)
plt.xlabel('Appliances')
plt.ylabel('Energy Usage (kWh)')
plt.title('Energy Usage of Household Appliances')
plt.show()
