import matplotlib.pyplot as plt

prices = [25, 30, 35, 40, 45, 28, 33, 37, 42, 50, 48, 31]

plt.hist(prices, bins=6, color='green', edgecolor='black')
plt.xlabel('House Price (Lakhs ₹)')
plt.ylabel('Number of Houses')
plt.title('Distribution of House Prices')
plt.show()
