import matplotlib.pyplot as plt

salary = [20000, 25000, 30000, 35000, 40000, 22000, 27000, 38000, 32000, 45000]

plt.hist(salary, bins=5, color='purple', edgecolor='black')
plt.xlabel('Salary (₹)')
plt.ylabel('Number of Employees')
plt.title('Salary Distribution in a Company')
plt.show()
