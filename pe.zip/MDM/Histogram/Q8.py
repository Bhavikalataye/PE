import matplotlib.pyplot as plt

speed = [60, 70, 75, 80, 90, 85, 95, 100, 110, 70, 65, 78, 88, 92]

plt.hist(speed, bins=6, color='cyan', edgecolor='black')
plt.xlabel('Speed (km/h)')
plt.ylabel('Number of Vehicles')
plt.title('Distribution of Vehicle Speeds')
plt.show()
