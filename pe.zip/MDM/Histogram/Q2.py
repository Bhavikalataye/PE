import matplotlib.pyplot as plt

scores = [45, 60, 70, 85, 90, 55, 65, 75, 80, 95, 50]

plt.hist(scores, bins=5, color='orange', edgecolor='black')
plt.xlabel('Marks')
plt.ylabel('Number of Students')
plt.title('Exam Score Distribution')
plt.show()
