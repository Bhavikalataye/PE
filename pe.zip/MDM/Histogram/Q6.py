import matplotlib.pyplot as plt

visitors = [100, 150, 200, 250, 180, 220, 300, 270, 230, 190, 160, 210, 240, 260, 280]

plt.hist(visitors, bins=6, color='red', edgecolor='black')
plt.xlabel('Number of Visitors')
plt.ylabel('Number of Days')
plt.title('Daily Visitors Distribution')
plt.show()
