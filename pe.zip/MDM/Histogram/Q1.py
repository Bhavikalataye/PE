import matplotlib.pyplot as plt

age = [18, 19, 18, 20, 21, 19, 20, 22, 21, 20]

plt.hist(age, bins=5, color='skyblue', edgecolor='black')
plt.xlabel('Age')
plt.ylabel('Number of Students')
plt.title('Age Distribution of Students')
plt.show()
