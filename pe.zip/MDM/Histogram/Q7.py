import matplotlib.pyplot as plt

delivery_time = [2, 3, 4, 5, 3, 2, 6, 4, 5, 3, 7, 2, 4, 5]

plt.hist(delivery_time, bins=5, color='gold', edgecolor='black')
plt.xlabel('Delivery Time (days)')
plt.ylabel('Number of Orders')
plt.title('Distribution of Delivery Times')
plt.show()
