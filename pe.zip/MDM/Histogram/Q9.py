import matplotlib.pyplot as plt

study_hours = [5, 7, 8, 10, 6, 9, 12, 11, 8, 10, 7, 6, 9, 10]

plt.hist(study_hours, bins=5, color='pink', edgecolor='black')
plt.xlabel('Study Hours per Week')
plt.ylabel('Number of Students')
plt.title('Study Hours Distribution')
plt.show()
