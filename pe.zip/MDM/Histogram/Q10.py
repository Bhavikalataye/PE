import matplotlib.pyplot as plt

ratings = [5, 4, 3, 5, 4, 2, 5, 3, 4, 5, 1, 4, 3, 5, 5]

plt.hist(ratings, bins=5, color='lightgreen', edgecolor='black')
plt.xlabel('Ratings (Stars)')
plt.ylabel('Number of Products')
plt.title('Product Ratings Distribution')
plt.show()
