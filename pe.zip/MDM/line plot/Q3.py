import matplotlib.pyplot as plt

# Months
months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']

# Revenue in lakhs (example data)
revenue = [50, 60, 65, 70, 80, 90]

# Plot the graph
plt.plot(months, revenue, marker='o')

# Add labels and title
plt.xlabel('Months')
plt.ylabel('Revenue (in lakhs)')
plt.title('Company Revenue Growth Over 6 Months')

# Show the graph
plt.show()
