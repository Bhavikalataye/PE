import matplotlib.pyplot as plt

days=['mon','tues','wed','thu','fri','sat','sun']

city1=[20,34,38,27,40,33,39]
city2=[24,30,35,23,26,39,29]

plt.plot(days,city1,marker='o',label=city1)
plt.plot(days,city2,marker='s',label=city2)

plt.xlabel("Days")
plt.ylabel("Temperature")
plt.title("Temperature in a week")

plt.legend()
plt.show()