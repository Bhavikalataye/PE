import matplotlib.pyplot as plt

days=['mon','tues','wed','thu','fri','sat','sun']

temperature=[20,34,38,27,40,33,39]

plt.plot(days,temperature,marker='o')
plt.xlabel("Days")
plt.ylabel("Temperature")
plt.title("Temperature in a week")
plt.show()