import matplotlib.pyplot as plt

# Time in minutes
time = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Heart rate in BPM (Beats Per Minute)
heart_rate = [72, 75, 78, 80, 82, 79, 77, 76, 74, 73]

# Plot the graph
plt.plot(time, heart_rate, marker='o')

# Add labels and title
plt.xlabel('Time (minutes)')
plt.ylabel('Heart Rate (BPM)')
plt.title('Heart Rate Recorded Every Minute')

# Show the graph
plt.show()
