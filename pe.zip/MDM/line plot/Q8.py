import matplotlib.pyplot as plt

# Test numbers
tests = ['Test 1', 'Test 2', 'Test 3', 'Test 4', 'Test 5']

# Scores out of 100
scores = [78, 82, 85, 90, 88]

# Plot the graph
plt.plot(tests, scores, marker='o')

# Add labels and title
plt.xlabel('Tests')
plt.ylabel('Scores')
plt.title('Math Test Scores Over 5 Tests')

# Show the graph
plt.show()
