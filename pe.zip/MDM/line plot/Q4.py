import matplotlib.pyplot as plt

# Time in seconds
time = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Speed in km/h
speed = [10, 20, 30, 40, 45, 50, 55, 58, 60, 62]

# Plot the graph
plt.plot(time, speed, marker='o')

# Add labels and title
plt.xlabel('Time (seconds)')
plt.ylabel('Speed (km/h)')
plt.title('Car Speed Over 10 Seconds')

# Show the graph
plt.show()
