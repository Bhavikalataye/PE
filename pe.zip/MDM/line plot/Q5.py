
import matplotlib.pyplot as plt

# Time of day (in hours)
time = ['6 AM', '9 AM', '12 PM', '3 PM', '6 PM', '9 PM', '12 AM']

# Electricity usage in units (example data)
usage = [10, 20, 35, 30, 40, 25, 15]

# Plot the graph
plt.plot(time, usage, marker='o')

# Add labels and title
plt.xlabel('Time of Day')
plt.ylabel('Electricity Usage (units)')
plt.title('Electricity Usage Throughout a Day')

# Show the graph
plt.show()
