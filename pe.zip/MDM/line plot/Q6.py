import matplotlib.pyplot as plt

# Trading days
days = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Stock prices in ₹
price = [150, 152, 149, 153, 155, 157, 160, 162, 161, 165]

# Plot the graph
plt.plot(days, price, marker='o')

# Add labels and title
plt.xlabel('Trading Days')
plt.ylabel('Stock Price (₹)')
plt.title('Stock Price Over 10 Trading Days')

# Show the graph
plt.show()
