import matplotlib.pyplot as plt

# Days of the week
days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

# Number of website visits each day
visits = [120, 150, 180, 200, 250, 300, 220]

# Plot the graph
plt.plot(days, visits, marker='o')

# Add labels and title
plt.xlabel('Days')
plt.ylabel('Website Visits')
plt.title('Daily Website Visits Over 7 Days')

# Show the graph
plt.show()
